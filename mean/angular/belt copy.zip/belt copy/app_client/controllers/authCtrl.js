angular.module('belt')
  .controller('authCtrl', ['$scope', '$location', 'authFactory', '$cookies', function($scope, $location, authFactory, $cookies){
    $scope.login = function(){
      authFactory.login({
        username: $scope.username
      }).then(function(user){
        $cookies.put('username', user.data.username);
        $scope.usernameCookie = $cookies.get('username');
        $location.url('/dashboard')
      }).catch(function(err){
        console.log(err);
      })
    }
}])
