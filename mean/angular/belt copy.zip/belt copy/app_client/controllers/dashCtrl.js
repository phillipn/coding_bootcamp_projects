angular.module('belt')
  .controller('dashCtrl', ['$scope', 'contentFactory', '$location', '$cookies', function($scope, contentFactory, $location, $cookies){

    $scope.username = $cookies.get('username')

    $scope.getSurveys = function(){
      contentFactory.getSurveys().then(function(surveys){
        console.log(surveys.data);
        $scope.surveys = surveys.data;
      }).catch(function(err){
        console.log(err);
      })
    }

    $scope.getSurveys()

    $scope.deleteSurvey = function(survey){
      contentFactory.deleteSurvey(survey._id).then(function(survey){
        console.log(survey);
        $scope.getSurveys()
      }).catch(function(err){
        console.log(err);
      })
    }
  }])
