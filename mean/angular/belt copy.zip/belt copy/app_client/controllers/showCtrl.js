angular.module('belt')
  .controller('showCtrl', ['$scope', '$route', 'contentFactory', '$location', '$cookies', function($scope, $route, contentFactory, $location, $cookies){
    $scope.getSurvey = function(){
      console.log($route.current.params.survey_id);
      contentFactory.getSurvey($route.current.params.survey_id).then(function(survey){
        console.log(survey);
        $scope.survey = survey.data
      }).catch(function(err){
        console.log(err);
      })
    }

    $scope.getSurvey()

    $scope.vote = function(choice, survey){
      contentFactory.vote(survey._id, {choice: choice}).then(function(survey){
        $scope.getSurvey()
      }).catch(function(err){
        console.log(err);
      })
    }
  }])
