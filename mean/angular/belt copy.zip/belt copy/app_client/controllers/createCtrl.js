angular.module('belt')
  .controller('createCtrl', ['$scope', 'contentFactory', '$location', '$cookies', function($scope, contentFactory, $location, $cookies){
    $scope.createSurvey = function(){
      var choices1 = [$scope.option2, $scope.option3, $scope.option4];
      var choices2 = [$scope.option1, $scope.option3, $scope.option4];
      var choices3 = [$scope.option1, $scope.option2, $scope.option4];
      var choices4 = [$scope.option1, $scope.option2, $scope.option3];

      if(choices1.indexOf($scope.option1) != -1 || choices2.indexOf($scope.option2) != -1 || choices3.indexOf($scope.option3) != -1 || choices4.indexOf($scope.option4) != -1){
        $scope.dupes = 'Cannot have identical values in choices';
        return false;
      }

      contentFactory.createSurvey({
        username: $cookies.get('username'),
        question: $scope.question,
        option1: $scope.option1,
        option2: $scope.option2,
        option3: $scope.option3,
        option4: $scope.option4
      }).then(function(survey){
        console.log(survey);
        $location.url('/dashboard')
      }).catch(function(err){
        console.log(err);
      })
    }
  }])
