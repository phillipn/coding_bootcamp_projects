angular.module('belt')
  .controller('navController', ['$scope', 'authFactory', '$location', '$cookies', function($scope, authFactory, $location, $cookies){
    $scope.loggedIn = $cookies.get('username');

    $scope.logout = function(){
      authFactory.logout();
      $location.url('/');
    }
  }])
