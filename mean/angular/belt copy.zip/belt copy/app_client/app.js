angular.module('belt', ['ngRoute', 'ngMessages', 'ngCookies']);

angular.module('belt').config(function($routeProvider){
  $routeProvider
    .when('/', {
      templateUrl: './templates/login.html',
      controller: 'authCtrl'
    })
    .when('/dashboard', {
      templateUrl: './templates/dash.html',
      controller: 'dashCtrl'
    })
    .when('/create', {
      templateUrl: './templates/create.html',
      controller: 'createCtrl'
    })
    .when('/surveys/:survey_id', {
      templateUrl: './templates/show.html',
      controller: 'showCtrl'
    })
    .otherwise('/')
})
