angular.module('belt')
  .factory('contentFactory', ['$http', '$cookies', function($http, $cookies){
    return {
      getSurveys: function(){
        return $http.get('/api/surveys')
      },
      getSurvey: function(survey_id){
        return $http.get('/api/surveys/' + survey_id)
      },
      createSurvey: function(obj){
        return $http.post('api/surveys', obj)
      },
      deleteSurvey: function(survey_id){
        return $http.delete('api/surveys/' + survey_id)
      },
      vote: function(survey_id, obj){
        return $http.put('api/surveys/' + survey_id, obj)
      }
    }
  }])
