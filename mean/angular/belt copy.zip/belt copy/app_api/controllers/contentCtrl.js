var mongoose = require('mongoose');
var User = require('../models/user.js');
var Survey = require('../models/survey.js')

var sendJSONResponse = function(res, status, data){
  res.status(status);
  res.json(data);
}

module.exports.getSurveys = function(req, res){
  Survey.find({}, function(err, results){
    if(err){
      console.log(err);
      sendJSONResponse(res, 400, err)
    } else {
      console.log(results);
      sendJSONResponse(res, 200, results)
    }
  })
}

module.exports.getSurvey = function(req, res){
  Survey.findOne({_id: req.params.survey_id}, function(err, survey){
    if(err){
      console.log(err);
      sendJSONResponse(res, 400, err)
    } else {
      console.log(survey);
      sendJSONResponse(res, 200, survey)
    }
  })
}

module.exports.createSurvey = function(req, res){
  Survey.create({
    username: req.body.username,
    question: req.body.question,
    choices: [req.body.option1, req.body.option2, req.body.option3, req.body.option4],
    votes: [0, 0, 0, 0]
  }, function(err, survey){
    if(err){
      console.log(err);
      sendJSONResponse(res, 400, err)
    } else {
      sendJSONResponse(res, 201, survey)
    }
  })
}

module.exports.deleteSurvey = function(req, res){
  Survey.remove({_id: req.params.survey_id}, function(err){
    if(err){
      console.log(err);
      sendJSONResponse(res, 400, err)
    } else {
      sendJSONResponse(res, 200, 'Deleted!')
    }
  })
}

module.exports.vote =  function(req, res){
  Survey.findOne({_id: req.params.survey_id}, function(err, survey){
    if(err){
      console.log(err);
      sendJSONResponse(res, 400, err)
    } else {
      var index = survey.choices.indexOf(req.body.choice);
      var numberOfVotes = survey.votes[index];
      survey.votes.set(index, numberOfVotes + 1);
      survey.save(function(err, survey){
        if(err){
          console.log(err);
          sendJSONResponse(res, 400, err)
        } else {
          sendJSONResponse(res, 200, survey)
        }
      })
    }
  })
}
