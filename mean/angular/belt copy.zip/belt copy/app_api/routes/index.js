var express = require('express');
var router = express.Router();
var authCtrl = require('../controllers/authCtrl.js');
var contentCtrl = require('../controllers/contentCtrl.js');

router.post('/users', authCtrl.login);

router.get('/surveys', contentCtrl.getSurveys);
router.post('/surveys', contentCtrl.createSurvey);
router.get('/surveys/:survey_id', contentCtrl.getSurvey)
router.put('/surveys/:survey_id', contentCtrl.vote)
router.delete('/surveys/:survey_id', contentCtrl.deleteSurvey)

module.exports = router
