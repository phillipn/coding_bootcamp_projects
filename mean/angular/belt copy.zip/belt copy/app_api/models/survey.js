var mongoose = require('mongoose');

var SurveySchema = new mongoose.Schema({
  username: {
    type: String,
    required: true
  },
  question: {
    type: String,
    required: true
  },
  choices: [{
    type: String,
    required: true
  }],
  votes: [{
    type: Number
  }]
}, {
  timestamps: true
});

module.exports = mongoose.model('Survey', SurveySchema)
